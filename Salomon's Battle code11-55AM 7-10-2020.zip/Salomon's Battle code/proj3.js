//It looks like all we have to do now is add the turn functionality, hook this into the database, add graphics & music, and the battles should be working.
//NOTE TO SELF: I may need to code the HTML in this file instead since a lot of it will be dynamic.
//NEW NOTE TO SELF: When outputting Pokemon or Pokedex stuff, make sure that the entry display is added by 1 because of array rules.
//Variables for some for loop conditions.

/*

--------------TO MY COLLABORATORS--------------
I have the opponent moveset up for debugging.

I decided to name all of them gengar for testing.
I made it so that all we need to do is get the info from the database, the battle logic is almost fully implemented.

To-do:
HUD touch up
Type advantages (2d array)
Proper display
disabling and enabling moves for when Pokemon die/revive.
Pokemon max,
using the appropriate item when clicked.
Implementing item dropdown.
*/ 

//Sees if this is the first Load or not. At the end make false.
var firstLoad=true;
var totalPlayerMoves=4;
var totalOpponentMoves=4;
var numOpponentItems=20;
var numPlayerItems=20;
//Number of Pokemon on a team.
var numPlayerPokemon=6;
var numOpponentPokemon=6;
var nve="nve";

//How long to wait before displaying.
var displaySpeed=3000;

//This is how many moves each Pokemon on the team has.
var playerMoveQuantity=new Array(numPlayerPokemon);
var opponentMoveQuantity=new Array(numOpponentPokemon);

//This represents what Pokemon is being currently used at the moment.
var currentPokemon=0;
var opponentCurrentPokemon=0;
var maxPokemon=151; //This is for catching and whatnot.

//Move object. Every move has these things.
class Move
{
    constructor(name,type,attack,specialAttack,status,buff,nerf,pp,ppMax)
    { 
    this.name="Solar beam";//String.
    this.type="grass";//String.
    this.attack=attack;//Int.
    this.specialAttack=specialAttack;//Int.
    this.status=status;//String.
    this.buff=buff;//Int. For moves like sword dance.
    this.nerf=nerf;//Int. For moves like growl
    this.pp=15;//How many times the Pokemon can do a move.
    this.ppMax=15; //Int. Maximum pp a move can have.
    }//End constructor

}; //End Move defn.

//Trainer object. Every trainer has a pokemon team.
class Trainer
{
    constructor(didCatchPokemon,name,gender,money,pokemonTeam,totalPokemon,expShare,items,isDefeated,img)
    {
    this.caughtPokemon=new Pokemon();//Nothing yet.
    this.didCatchPokemon=false;
    this.name=name;
    this.gender=gender;
    this.money=money;
    this.pokemonTeam=pokemonTeam; //Array of Pokemon.
    this.totalPokemon=totalPokemon; //How much Pokemon is caught total.. (Team & PC)
    this.expShare=expShare; //Does the trainer have exp share?
    this.items=items;//Items to recover the Pokemon or other things.
    this.isDefeated=isDefeated;
    this.img=img;//Trainer image

    }//End constructor
};//End Trainer defn.

//Whoever I'm facing.
class Opponent
{
    constructor(name,gender,money,pokemonTeam,items,isDefeated,img)
    {
    this.name=name;
    this.gender=gender;
    this.money=money;
    this.pokemonTeam=pokemonTeam; //Array of Pokemon.
    this.items=items;
    this.isDefeated=isDefeated;
    this.img=img; //For loading the visuals
    }//End constructor
};//End Opponent defn.

//Pokemon class. Every Pokemon has these things.
class Pokemon
{   //Keep in mind that these are the base stats of the Pokemon
    constructor(isAlive, isWild,name,isCaught,hp,dexNumber,type1,type2,attack,defense,specialAttack,specialDefense,speed,generation,legendary,level,currentHp,currentAttack,nextLevelFormula,currentDefense,currentSpecialAttack,currentSpecialDefense,currentSpeed,expValue,moveQuantity,moveset,img)
    {
    //Some of these are old variables from planning. I want to play with the database before making the decision to delete them and everything.
    this.isAlive=true; //Boolean. Is the Pokemon alive?
    this.isWild=false; //Boolean.   If it's not wild, then increase exp. 
    this.name="Gengar";//String.
    this.isCaught=false;
    this.hp=100;//Int. 
    this.dexNumber=0;//Int. 
    this.type1="";//String.
    this.type2="";//String.
    this.attack=0;//Int. 
    this.defense=0;//Int. 
    this.specialAttack=0;//Int. 
    this.specialDefense=0;//Int. 
    this.speed=0;//Int. 
    this.generation=0;//Int. 
    this.legendary=false;
    this.level=0;//Int. 
    this.currentHp=0;//Int. 
    this.currentAttack=0;//Int. 
    this.nextLevelFormula=this.level*this.hp;//Do this after leveling up
    this.currentDefense=0;//Int. 
    this.currentSpecialAttack=0;//Int. 
    this.currentSpecialDefense=0;//Int. 
    this.currentSpeed=0;//Int. 
    this.expValue=(hp*attack*speed*defense)/level;////Int. How much exp the Pokemon costs after being beaten.
    this.moveQuantity=4;//How many moves the Pokemon has.
    this.moveset=new Array(); //Array of moves.
    this.img=img;//Pokemon image //Could be an array of sprites, the battle image and icon, etc..
    //Initialize moveset:

    
    //exp/level up logic
    
    //exp=0;//How much exp the Pokemon costs after being beaten.
    //pokemon.toNextLevel-=pokemon.expValue; //if (pokemon.toNextLevel<=0) {pokemon.toNextLevel-= (pokemon.toNextLevel-pokemon.expValue); pokemon.level+=1; pokemon.hp+=Math.random()*10+1 pokemon.toNextLevel=nextLevelFormula;}
    //pokemon.totalExp+=pokemon.exp;
    //
    this.totalExp=0;
    this.currentExp=0;
    this.toNextLevel=nextLevelFormula; //Exp to the next level. Let's keep it like FFVIII for now.
    }//End constructor
};//End Pokemon defn.

class Item
{
    constructor(name,quantity,value,purpose,img)
    {
        this.name=name;//String.
        this.quantity=quantity//Int.
        this.value=value;//Int.
        this.purpose=purpose; //String.
        this.img=img;
    }//End constructor
    
}//End Item defn.





//Initializing things for battle.
var team=new Array(numPlayerPokemon);
var items=new Array(numPlayerItems);

var opponentTeam=new Array(numOpponentPokemon);
var opponentItems=new Array(numOpponentItems);

var totalPokemon=new Array(maxPokemon);

//This loop initializes the player's items.
for(i=0;i<numPlayerItems;i++)
{
    items[i]=new Item("potion",20,20,"healing");
}//End for

//This loop initializes the opponent's items.
for(i=0;i<numOpponentItems;i++)
{
    opponentItems[i]=new Item("potion",20,40,"healing");
}//End for

var player = new Trainer(false,"Ash","boy",500,team,totalPokemon,true,items,false);
var opponent= new Opponent("Gary","boy",5000,opponentTeam,opponentItems,false);

//This loop initializes the opponent's Pokemon team.
for(i=0;i<numOpponentPokemon;i++)
{
    opponent.pokemonTeam[i]=new Pokemon();
}//End for

//This initializes the total amount of Pokemon the Trainer/User has caught.
for(i=0;i<maxPokemon;i++)
{
    player.totalPokemon[i]=new Pokemon();
}//End for


//This loop initializes the player's Pokemon team.
for(i=0;i<numPlayerPokemon;i++)
{
    player.pokemonTeam[i]=new Pokemon();
}//End for



//Putting what I have in my team into my total Pokemon.
for(i=0;i<numPlayerPokemon;i++)
{
    //I mod the corresponding dex number by the total amount to easily be able to sort through them and not worry about out of bounds.
    //Then I set the corresponding pokemon to that spot in the array.
    
    player.totalPokemon[player.pokemonTeam[i].dexNumber%maxPokemon]=player.pokemonTeam[i];
    
}//End for


//This loop initializes the player's Pokemon team's moves.
for(i=0; i<numPlayerPokemon; i++)
{   //console.log("quantity is: "+player.pokemonTeam[i].moveQuantity);
    for(j=0; j<player.pokemonTeam[i].moveQuantity; j++)
    {
        player.pokemonTeam[i].moveset[j]=new Move();
    }//End inner for


}//End outer for

//This loop initializes the quantity of moves per Pokemon on the opponent's team.
for(i=0; i<numOpponentPokemon; i++)
{   //console.log("op quantity is: "+opponent.pokemonTeam[i].moveQuantity);
    for(j=0; j<opponent.pokemonTeam[i].moveQuantity; j++)
        {
            opponent.pokemonTeam[i].moveset[j]=new Move();
        }//End inner for
}//End outer for

var playerPokemonFaintMsg=player.pokemonTeam[currentPokemon].name+"fainted!";
var lowPpMsg="No more PP!! ";
//This will add to the total amount of pokemon the trainer has when a new Pokemon is caught.
/*

----------------------------BEGIN PROGRAM------


*/
function addPokemon(caughtPokemon)
{
    player.didCatchPokemon=true;//The player DID catch a Pokemon.
    player.totalPokemon[caughtPokemon.dexNumber%maxPokemon]=caughtPokemon;
}

var c=document.getElementById("canvas");
var context=c.getContext("2d");
var step=30;//How many pixels the image moves per redraw. 

//For movement
var x=0;
var y=0;

//For animation
/*
left:   sx[0] 
up:     sx[1]
right:  sx[2]
down:   sx[3]
*/
var sx=new Array(4); //Source x array for the 4 directions
sx[0]=0;
sx[1]=1020; //Have to start here for the up sprite strip
sx[2]=0;
sx[3]=0;
var sy=new Array(4); //Source y for 

var height=300;
var width=230;
var reset=0; //Supposed to clear setInterval().

var img=document.getElementById("sheet");//New image object & connecting the source
context.drawImage(img,0,0,img.width/8.7,img.height/3.5,x,y,width,height);




//Just display text to the user. Make pretty.
function display(dispstring)
{   
    var disp=document.getElementById("display");
    disp.innerHTML=dispstring;
    //console.log("I clicked next");
    //Before and/or after every display(), have the text come out slowly. Wait maybe some milliseconds per letter.
    //Display border with text that outputs.
    return;
}

function nextMsg()
{
   // console.log("bruhhhhhhh");
    return true;

}//End nextMsg
//Thanks to this.id, I can pass on the movename into this function.

function attackPlayer(moveId)
{   
    (opponentChoice=Math.floor(Math.random()*4)+1);//Random number in the range [1,4].
    var numPlayerPokemonFainted=0;
    var moveChoice=0;
    //"move"+(num+1);
    //This variable determines if it's in the class opponent or player
    //Is the player executing a move or is the opponent executing a move?
    var moveExecuted=document.getElementById("opmove"+(opponentChoice));
    //console.log("This should work: ",moveExecuted.id);
    display(moveExecuted.id);
    //This Pokemon used its move on the player.
    //Passing in the pokemon
    decreasePlayerHealth();
    
    switch(moveExecuted.id)
    {
        case "opmove1":
            {
                moveChoice=0;
                break;
            }//End case
            
        case "opmove2":
            {
                moveChoice=1;
                break;
            }//End case
            
        case "opmove3":
            {
                moveChoice=2;
                break;
            }//End case
            
                    
        case "opmove4":
            {
                moveChoice=3;
                break;
            }//End case
            
            
        }//End switch
    moveChoice=moveChoice%opponent.pokemonTeam[opponentCurrentPokemon].moveQuantity; //Move choice can only be as big as the quantity.
    //console.log("choice is "+moveChoice);
    opponent.pokemonTeam[opponentCurrentPokemon].moveset[moveChoice].pp-=1;
    moveExecuted.innerHTML=opponent.pokemonTeam[opponentCurrentPokemon].moveset[moveChoice].name+"<br>"+"PP: "+opponent.pokemonTeam[opponentCurrentPokemon].moveset[moveChoice].pp+"/"+opponent.pokemonTeam[opponentCurrentPokemon].moveset[moveChoice].ppMax;        
    attackMsg=opponent.name+"'s "+opponent.pokemonTeam[opponentCurrentPokemon].name+" used "+ opponent.pokemonTeam[opponentCurrentPokemon].moveset[moveChoice].name+"!";
    
    //console.log("PP nOW: "+ opponent.pokemonTeam[opponentCurrentPokemon].moveset[moveChoice].pp);
    //If the pp runs out,disable the move.
    if(opponent.pokemonTeam[opponentCurrentPokemon].moveset[moveChoice].pp<=0)
    {
        
        disableMove(moveChoice,false);
    }//End if
    if(!(opponent.pokemonTeam[opponentCurrentPokemon].moveset[moveChoice].pp<=0)) //If the current PP value isn't less than or equal to 0, make sure this move is enabled.
    {
        
        enableMove(moveChoice,false);
    }//End if
    display(attackMsg);//This will display to the screen
    
    //After decreasing, check to see if the pokemon died.
    for(i=0; i<numPlayerPokemon; i++)
    {  // console.log("I'm in.");
        //If my Pokemon's HP reaches less than or equal to zero, then my Pokemon has fainted.
        if(player.pokemonTeam[i].hp<=0)
        {
            numPlayerPokemonFainted+=1;
        }//End if
    }//End for

    console.log(numPlayerPokemonFainted+" of the player's Pokemon is currently fainted");
    //Seeing if the team is knocked out or not.
    if(numPlayerPokemonFainted==player.pokemonTeam.length)
    {   faintMsg="haHAAAa your pokemon died you suck haha";
        display(faintMsg);
        player.isDefeated=true;
        end();
    }
    //If my count is 
    //Do what happens when a move is executed.
}//End attackPlayer

function disableMove(num,user)
{
    //This function disables the move when PP is out.
    if(user)
    {   
        //I need to increment 1 so it matches the string perfectly.
        moveId="move"+(num+1);
        //console.log("This move should get disabled bro: ",moveId);
        move=document.getElementById(moveId);
        move.disabled=true;
    }//End if
    else //Otherwise enable the opponent's move
    {
        //I need to increment 1 so it matches the string perfectly.
        moveId="opmove"+(num+1); 
        //console.log("This move should get disabled bro: ",moveId);
        move=document.getElementById(moveId);
        move.disabled=true;

    }//End else
}//End disableMove

//This function enables the move when PP is up or a Pokemon is switched.
function enableMove(num,user)
{
    //If it's on the user side, do this code.
    if(user)
    {   
        //I need to increment 1 so it matches the string perfectly.
        moveId="move"+(num+1);
        //console.log("This move should get enabled bro: ",moveId);
        move=document.getElementById(moveId);
        move.disabled=false;
    }//End if
    else //Otherwise enable the opponent's move
    {
        //I need to increment 1 so it matches the string perfectly.
        moveId="opmove"+(num+1); 
        //console.log("This move should get enabled bro: ",moveId);
        move=document.getElementById(moveId);
        move.disabled=false;

    }//End else
}

function attackOpponent(moveId)
{   var moveChoice=0;
    

    var numOpponentPokemonFainted=0;

    //This variable determines if it's in the class opponent or player
    //Is the player executing a move or is the opponent executing a move?
    var moveExecuted=document.getElementById(moveId);
    display(moveExecuted.id);
    
    //latestmove.className=player.pokemonTeam[currentPokemon].moveset[currentPokemon].type;
    //console.log(latestmove);
    //Get the number of the move I picked.
    switch(moveExecuted.id)
        {
        case "move1":
        {
            moveChoice=0;
            break;
        }//End case
        
        case "move2":
            {
                moveChoice=1;
                break;
            }//End case
            
        case "move3":
            {
                moveChoice=2;
                break;
            }//End case


        case "move4":
            {
                moveChoice=3;
                break;
            }//End case
    
    
    }//End switch
    moveChoice=moveChoice%player.pokemonTeam[currentPokemon].moveQuantity; //Move choice can only be as big as the quantity.
    var string=player.name+"'s "+player.pokemonTeam[currentPokemon].name+" used "+ player.pokemonTeam[currentPokemon].moveset[moveChoice].name+"!";
    //Passing in the pokemon
    decreaseOpponentHealth(player.pokemonTeam[currentPokemon]);
    string="Testing test";
    display(string);//This will display to the screen
    
    //pp goes down after hit lands
    let x=player.pokemonTeam[currentPokemon].moveset[moveChoice].pp-=1;
    moveExecuted.innerHTML=player.pokemonTeam[currentPokemon].moveset[moveChoice].name+"<br>"+"PP: "+player.pokemonTeam[currentPokemon].moveset[moveChoice].pp+"/"+player.pokemonTeam[currentPokemon].moveset[moveChoice].ppMax;

    //If the pp runs out,disable the move.
    if(player.pokemonTeam[currentPokemon].moveset[moveChoice].pp<=0)
    {
        //disable move.
        disableMove(moveChoice,true);
    }//End if
    if(!(player.pokemonTeam[currentPokemon].moveset[moveChoice].pp<=0)) //If the current PP value isn't less than or equal to 0, make sure this move is enabled.
    {
        //Enable move.
        enableMove(moveChoice,true);
    }//End if

    //After decreasing, check to see if the pokemon of the opponent's team died.
    for(i=0; i<numOpponentPokemon; i++)
    {   //If the HP of the opponent's Pokemon reaches less than or equal to zero, then their Pokemon has fainted.
        if(opponent.pokemonTeam[i].hp<=0)
        {
            //When they're dead, they're dead.
            numOpponentPokemonFainted+=1;
            //
            //disablePokemon(opponent.pokemonTeam[opponentCurrentPokemon],opponentCurrentPokemon);
            //enablePokemon();
            //switchOpponentPokemon();
        }//End if
    }//End for

    //if(numPokemonFainted!=)
    //{}

    console.log(numOpponentPokemonFainted+" of the opponent's Pokemon is currently fainted");
    //Seeing if the team is knocked out or not.
    if(numOpponentPokemonFainted==player.pokemonTeam.length)
    {   
        opponent.isDefeated=true;
        var victoryMsg="ahahah the tRUE gamer won hahaahahahhaahahaha";
        display(victoryMsg);
        end();
    }
    //If my count is 
    //Do what happens when a move is executed.
    
    
    opponentTurn();
}//End attackOpponent

//this function takes in a Pokemon object and the index of the Pokemon
function disablePokemon(pokemon)
{

}//End disablePokemon

function enablePokemon(pokemon)
{

}//End enablePokemon

function usePlayerItem(itemId)
{
    var playerChoice=0;   //Random number from 0 to amount of items he has.
    //Get this from a dropdown list.
    itemChoice=itemId.options.selectedIndex;
    itemChoice-=1;
    
    /*
    --------------------------MAKE SURE THAT THE USER ITEMS ARE PROPERLY SETTLED!!!--------------------------
    
    */
   //console.log(player.items[0]);
   player.items[playerChoice].purpose="healing";
   player.items[playerChoice].value=40;

    if(player.items[playerChoice].purpose=="healing")
    {
        recovery=player.items[playerChoice].value;
        //console.log("Recovered by " +recovery);
        var health=document.getElementById("player");
        //I decrease the health bar and the actual hp of the Pokemon that is out right now.
        health.value+=recovery;
        player.pokemonTeam[currentPokemon].hp+=recovery;
        display(player.pokemonTeam[currentPokemon].name+"'s Health went up by " + recovery+"!!"),displaySpeed;
    }//End if
    
    //Decreasing the quantity of the item
    player.items[playerChoice].quantity-=1;
    console.log(player.name+ " used "+player.items[playerChoice].name+" on "+player.pokemonTeam[currentPokemon].name);//This will display to the screen

    //Do what happens when a move is executed.
}//End usePlayerItem

function useOpponentItem()
{
    opponentChoice=Math.floor(Math.random()*opponent.items.length);   //Random number from 0 to amount of items he has.
    console.log(opponent.name+ "used "+opponent.items[opponentChoice].name+" on "+opponent.pokemonTeam[opponentCurrentPokemon].name);//This will display to the screen
    if(opponent.items[opponentChoice].purpose=="healing")
    {
        recovery=opponent.items[opponentChoice].value;
        console.log("Recovered by " +recovery);
        var health=document.getElementById("opponent");
        //I decrease the health bar and the actual hp of the Pokemon that is out right now.
        health.value+=recovery;
        opponent.pokemonTeam[opponentCurrentPokemon].hp+=recovery;
        display(opponent.pokemonTeam[opponentCurrentPokemon].name+"'s Health went up by " + recovery+"!!");
    }//End if

    if(opponent.items[opponentChoice].purpose=="revival")
    {
        recovery=opponent.items[opponentChoice].value;
        console.log("Recovered by " +recovery);
        var health=document.getElementById("opponent");
        //I decrease the health bar and the actual hp of the Pokemon that is out right now.
        health.value+=recovery;
        opponent.pokemonTeam[opponentCurrentPokemon].hp+=recovery;
        display(opponent.pokemonTeam[opponentCurrentPokemon].name+"'s Health went up by " + recovery+"!!");
    }//End if
    //Do what happens when a move is executed.
}//End useOpponentItem


function getMoveName(pokemon)
{
    return ;
}//End getMoveName





//Takes in a pokemon object and an attack
function decreaseOpponentHealth()
{   attack=10;
    var attackTotal=0;
    attackTotal+=player.pokemonTeam[currentPokemon].attack+51;
    var numOpponentPokemonFainted=0;
    var effective=isEffective();
    var health=document.getElementById("opponent");
    //console.log("Opponent current Pokemon:" +opponentCurrentPokemon);
    health.value=opponent.pokemonTeam[opponentCurrentPokemon].hp;
    //Goes down the attackTotal
    for(i=0;i<attackTotal;i++)
    {
        health.value-=1;
        opponent.pokemonTeam[opponentCurrentPokemon].hp-=1;

    }//End for

    //Confirm a faint in the opponent's team. It always checks to see if each team member has fainted.
    if(opponent.pokemonTeam[opponentCurrentPokemon].hp<=0)
    {  
        console.log(opponent.name+"'s "+opponent.pokemonTeam[opponentCurrentPokemon].name+" is dead. " +"ID:"+opponentCurrentPokemon);
        opponent.pokemonTeam[opponentCurrentPokemon].isAlive=false;
        faintMsg=opponent.name+"'s "+opponent.pokemonTeam[opponentCurrentPokemon].name+"fainted!";
        //PUT THE WIN/LOSS CODE HERE AND DETERMINE VICTORY HERE!!
        
        //This for loop iterates through the opponent's team to see if they're all dead.
        for(i=0; i<numOpponentPokemon; i++)
        {   //If the HP of the opponent's Pokemon reaches less than or equal to zero, then their Pokemon has fainted.
            if(opponent.pokemonTeam[i].hp<=0)
            {
                //When they're dead, they're dead.
                numOpponentPokemonFainted+=1;
                opponent.pokemonTeam[i].isAlive=false;

            }//End if
        }//End for
        
        if(numOpponentPokemonFainted==numOpponentPokemon)
        {
            opponent.isDefeated=true;
            //End battle here. No need for any further calculations.
            end();
        }//End if
        display(faintMsg);
        switchOpponentPokemon(); //The opponent switches when dead.
    }//End outer if
    display(opponent.pokemonTeam[opponentCurrentPokemon].name +"'s Health went down by "+attackTotal+"!!");
}//End decreaseOpponentHealth

//The opponent attacks the player.
function decreasePlayerHealth()
{   
    var numPlayerPokemonFainted=0;//Keeps track of the player Pokemon fainted
    var attackTotal=0;
    attackTotal+=player.pokemonTeam[currentPokemon].attack+14;
    var health=document.getElementById("player");
    health.value=player.pokemonTeam[currentPokemon].hp;
    //If it's super effective, do more damage.
    //If it is effective, add on.
    
    // if(isEffective())
    // {
    //     attackTotal+=(opponent.pokemonTeam[opponentCurrentPokemon].attack+opponent.pokemonTeam[opponentCurrentPokemon].specialAttack);
    // }
    // else if(!isEffective())
    // {
    //     attackTotal+=attackTotalopponent.pokemonTeam[opponentCurrentPokemon].attack;
    // }
    // else if(isEffective()==notVeryEffective)

    for(i=0;i<attackTotal;i++)
    {
        
        player.pokemonTeam[currentPokemon].hp-=1;
        health.value-=1;
    }//End for

//Confirm a faint in the player's team. It always checks to see if each team member has fainted.
    if(player.pokemonTeam[currentPokemon].hp<=0)
    {  
        console.log(player.name+"'s "+player.pokemonTeam[currentPokemon].name+" is dead. " +"ID:"+currentPokemon);
        player.pokemonTeam[currentPokemon].isAlive=false;
        faintMsg=player.name+"'s "+player.pokemonTeam[currentPokemon].name+"fainted!";
        //PUT THE WIN/LOSS CODE HERE AND DETERMINE VICTORY HERE!!
        
        //This for loop iterates through the opponent's team to see if they're all dead.
        for(i=0; i<numPlayerPokemon; i++)
        {   //If the HP of the opponent's Pokemon reaches less than or equal to zero, then their Pokemon has fainted.
            if(player.pokemonTeam[i].hp<=0)
            {
                //When they're dead, they're dead.
                numPlayerPokemonFainted+=1;
                player.pokemonTeam[i].isAlive=false;

            }//End if
        }//End for
        
        if(numPlayerPokemonFainted==numPlayerPokemon)
        {
            player.isDefeated=true;
            //End battle here. No need for any further calculations.
            end();
        }//End if
        //console.log("HP: "+ player.pokemonTeam[currentPokemon].hp);
        display(player.pokemonTeam[currentPokemon].name +"'s Health went down by "+attackTotal+"!!");
    }//End if
}//End decreasePlayerHealth


function switchPlayerPokemon(switchId)
{
    //console.log("YESSS "+switchId.options.selectedIndex);
    //I'll

    // var choice=document.getElementById("2");
    // console.log("My choice is:" +choice.id);
    // //The array represents the options.
    // console.log("My choice is:" +switchId[5].value);
    //Switches the Pokemon
    //Since I offset the options with the default switch option, I need to decrement by 1 to keep the array in check.
    currentPokemon=switchId.options.selectedIndex;
    currentPokemon-=1;
    
    //The idea behind this is that the user picks a pokemon with a button and it will return a number between 0 and numPokemon
    //currentPokemon+=1;
    //currentPokemon=(currentPokemon%numPlayerPokemon); 
    
    //May need to reload
    load();
    
    //Switch Pokemon
}//End switchPlayerPokemon


function switchOpponentPokemon()
{   
    //Save this in case the trainer tries switching
    if(opponent.isDefeated==true)//Just return if defeated.
    {
        return;
    }//End if
    var previousOpponentCurrentPokemon=opponentCurrentPokemon;
    var choice=1;
    //The idea behind this is that the user picks a pokemon with a button and it will return a number between 0 and numPokemon
    opponentCurrentPokemon+=1;
    opponentChoice=Math.floor(Math.random()*numOpponentPokemon);//Random number in the range [1,3].
    opponentCurrentPokemon=(opponentCurrentPokemon%numOpponentPokemon); 
    
    /*
    If the pokemon the opponent is about to pick isn't alive, go to the next. Keep going until there IS one that is alive.
    //I do i + numOpponentPokemon because I want it to start at whatever number and look through the whole buffer. know I can achieve that by having the length of the loop extended.
    //So if I start at 4, and numOpponentPokemon is 6, I'll get 4+6.

    4%6=4.
    5%6=5.
    6%6=0.
    7%6=1.
    8%6=2. 
    9%6=3.

    */
//This loop switches the pokemon
    try
    {

        for(i=opponentCurrentPokemon;i<(i+numOpponentPokemon);i++)
        {
            if(opponent.pokemonTeam[opponentCurrentPokemon].isAlive==false)
            {
                console.log("inner i:" +i);
                //Increase by one
                //opponentCurrentPokemon+=1;
                opponentCurrentPokemon=(i%numOpponentPokemon); //Circular searching

            }
            else
            {
                opponentCurrentPokemon=i; //This code causes an error when there's only one Pokemon left.
                console.log(opponent.name+" switched to "+opponent.pokemonTeam[opponentCurrentPokemon].name+"!!");
                break;
            }
            console.log("My i val is: "+i +" and numOpponentPokemon is "+ numOpponentPokemon);
        }//End for
    }//End try
catch(err)
{
    opponentCurrentPokemon=previousOpponentCurrentPokemon;
    error=opponent.name+" tried switching, but "+opponent.pokemonTeam[opponentCurrentPokemon].name+" is the last Pokemon!!";
    display(error);
    console.log(err);
    
}//End catch
    //console.log("wait a minute... "+opponentCurrentPokemon);
    

    //May need to reload
    load();
    //Switch Pokemon
}//End switchOpponentPokemon


//Make a wait function and inside of it, disable the buttons first
function opponentTurn()
{
    //If my opponent lost, just return.
    if(opponent.isDefeated==true)
    {
        console.log(opponent.isDefeated);
        return;
    }//End if
    move1=document.getElementById("move1");
    move2=document.getElementById("move2");
    move3=document.getElementById("move3");
    move4=document.getElementById("move4");
    for(i=0;i<totalPlayerMoves;i++)
    {
        disableMove(i,true);
    }//End for
    
    //Make the opponent make their random choices here. If I knew AI in JS I'd implement minimax or something.
    //For now, let's use randomization and a switch statement.

    opponentChoice=Math.floor(Math.random()*3)+1;//Random number in the range [1,3].
    display("Opponent choice: "+opponentChoice);
    switch(opponentChoice)
    {   //Attack player
        case 1:
            {
                display(opponent.name+"Goes for an attack!");
                attackPlayer();
                break;
            }//End case 1
            
            //Use item
            case 2:
            {
                //display(opponent.name+"Tries to use an item!");
                //useOpponentItem();
                break;
            }//End case 1
            
            case 3:
            {
                //display(opponent.name+" Switches Pokemon!");
                //switchOpponentPokemon();
                break;
            }//End case 1
                
        
    }//End switch

    //Reenable buttons before I can take a turn.
    for(i=0;i<totalPlayerMoves;i++)
    {
        enableMove(i,true);
    
    }//End for

    load();

}//End wait


function isEffective(moveType,pokemonType)
{
    //Try 
    //Just code up all the type advantages by using a 2D array.
    
    return nve;

}//End checkIfEffective

//This is where I update all the latest Pokemon data.
function load()
{
    var move=new Array();
    var opMove=new Array();
    //The default ids are called these so it will always initialize properly.
    move[0]=document.getElementById("move1");
    move[1]=document.getElementById("move2");
    move[2]=document.getElementById("move3");
    move[3]=document.getElementById("move4");
    //console.log("CLASS "+move[0].className);
    opMove[0]=document.getElementById("opmove1");
    opMove[1]=document.getElementById("opmove2");
    opMove[2]=document.getElementById("opmove3");
    opMove[3]=document.getElementById("opmove4");
    playerPokemonName=document.getElementById("playerpokemonname");
    opponentPokemonName=document.getElementById("opponentpokemonname");
    var opHealth=document.getElementById("opponent");
    var health=document.getElementById("player");
    //This updates the values on screen as I want it.
    opHealth.value=opponent.pokemonTeam[opponentCurrentPokemon].hp;
    health.value=player.pokemonTeam[currentPokemon].hp;
    //console.log("currentpokemon: "+currentPokemon);
    //console.log("playername: "+player.name);
    //console.log("currentpokemonname: "+player.pokemonTeam[currentPokemon].name);
    //console.log("currentpokemonmovename: "+player.pokemonTeam[currentPokemon].moveset[0].name);


    //This loop updated the look and feel of the buttons for the player.
    for(i=0;i<player.pokemonTeam[currentPokemon].moveset.length; i++)
    {
        move[i].innerHTML=player.pokemonTeam[currentPokemon].moveset[i].name+"<br>"+"PP: "+player.pokemonTeam[currentPokemon].moveset[i].pp+"/"+player.pokemonTeam[currentPokemon].moveset[i].ppMax;
    }//End for

    //This loop updated the look and feel of the buttons for the opponent.
    for(i=0;i<opponent.pokemonTeam[opponentCurrentPokemon].moveset.length; i++)
    {
        opMove[i].innerHTML=opponent.pokemonTeam[opponentCurrentPokemon].moveset[i].name+"<br>"+"PP: "+opponent.pokemonTeam[opponentCurrentPokemon].moveset[i].pp+"/"+opponent.pokemonTeam[opponentCurrentPokemon].moveset[i].ppMax;
    }//End for

    playerPokemonName.innerHTML=player.pokemonTeam[currentPokemon].name +" pokemonid: "+(currentPokemon+1);
    opponentPokemonName.innerHTML=opponent.pokemonTeam[opponentCurrentPokemon].name + " pokemonid: "+(opponentCurrentPokemon+1);

    //If the opponent's pokemon is dead, then they can't use any moves. They can only switch or use items.
    for(i=0;i<opponent.pokemonTeam[opponentCurrentPokemon].moveset.length; i++)
    {   
        if(opponent.pokemonTeam[opponentCurrentPokemon].isAlive==false)
        {   
            //console.log("Enabling move...");
            disableMove(i,false);
        
        }//End if
        //Otherwise, if they got HP from a revive or something, enable them again.
        else if(opponent.pokemonTeam[opponentCurrentPokemon].isAlive==true||opponent.pokemonTeam[opponentCurrentPokemon].hp>1)
        {
            //console.log("Disabling move...");
            opponent.pokemonTeam[opponentCurrentPokemon].isAlive=true;
            enableMove(i,false);

        }//End else
    }//End for


    //If the player's pokemon is dead, then they can't use any moves. They can only switch or use items.
    for(i=0;i<player.pokemonTeam[currentPokemon].moveset.length; i++)
    {   
        if(player.pokemonTeam[currentPokemon].isAlive==false)
        {   
            //console.log("Enabling move...");
            disableMove(i,false);
        
        }//End if
        //Otherwise, if they got HP from a revive or something, enable them again.
        else if(player.pokemonTeam[currentPokemon].isAlive==true||player.pokemonTeam[currentPokemon].hp>1)
        {
            //console.log("Disabling move...");
            player.pokemonTeam[currentPokemon].isAlive=true;
            enableMove(i,false);

        }//End else
    }//End for

    //This loop enables moves for when a Pokemon gets switched and another one's pp is out. (Opponent)
    for(i=0;i<opponent.pokemonTeam[opponentCurrentPokemon].moveset.length; i++)
    {   
        if(!(opponent.pokemonTeam[opponentCurrentPokemon].moveset[i].pp<=0))
        {   //console.log("Enabling move...");
            enableMove(i,false);

        }//End if
        else//Otherwise if it is less than or equal to 0 then disable it.
        {
            //console.log("Disabling move...");
            disableMove(i,false);

        }//End else
    }//End for

    //This loop enables moves for when a Pokemon gets switched and another one's pp is out. (Player)
    for(i=0;i<player.pokemonTeam[currentPokemon].moveQuantity; i++)
    {
        if(!(player.pokemonTeam[currentPokemon].moveset[i].pp<=0))
        {   //console.log("Enabling move...");
            enableMove(i,true);

        }//End if
        else //Otherwise if it is less than or equal to 0 then disable it.
        {
            //console.log("Enabling move...");
            disableMove(i,true);

        }//End else
    }//End for


    //The pokemon team and moves should all be properly initialized before this is called.
    //For every pokemon, all 4 of their moves get loaded in.
    for(i=0; i<numPlayerPokemon; i++)
    {   
        //console.log(i);
        //opHealth.value=opponent.pokemonTeam[i].hp;
        //health.value=player.pokemonTeam[i].hp;

        //The loop only goes up to however many moves each Pokemon has.
        for(j=0; j<player.pokemonTeam[i].moveQuantity; j++)
        {
        //console.log(j);
        //Friendly reminder that I used the CSS classes to represent the types for the buttons.
        //console.log(player.pokemonTeam[i].moveset[j].type);
        move[j].className=player.pokemonTeam[i].moveset[j].type;
        //If the class is default, then it wasn't initialized.
        
        // if(move[j].className=="default")
        // {
        //     disableMove(j,true);
        // }//End if

        }//End inner for

    }//End outer for

    
    for(i=0; i<numOpponentPokemon; i++)
    {   
        //opHealth.value=opponent.pokemonTeam[i].hp;
        //health.value=player.pokemonTeam[i].hp;
        for(j=0; j<opponent.pokemonTeam[i].moveQuantity; j++)
        {    
        
        //Loading opponent data
        
        
        opMove[j].className=opponent.pokemonTeam[i].moveset[j].type;
        //console.log("hmHHMMM"+opMove[j].className);
        if(opMove[j].className=="default")
        {
            disableMove(j,false);
        }//End if
        
        //Setting the move name to the opponent's
        
        }//End inner for
        
    }//End outer for

    //This for loop goes through all possible moves and disables anything that doesn't exist. (Player)
    for(i=0;i<totalPlayerMoves;i++)
    {
       //console.log("Player"+ move[i].className);
        if(move[i].className=="default")
        {
            disableMove(i,true);
        }//End if
    }//End for

    //This for loop goes through all possible moves and disables anything that doesn't exist. (Opponent)
    for(i=0;i<totalOpponentMoves;i++)
    {
        //console.log("CPU "+opMove[i].className);
        if(opMove[i].className=="default")
        {   
            disableMove(i,false);
        }//End if
    }//End for


    //I'm going to dynamically make the drop down menu so that it changes per load call.
    //This is only going to be for the player. The CPU is automatic.

    //Make an array and each element will be a line of code that will insert a choice for Pokemon.
    
    
    var selectPokemon=document.getElementById("switchplayerpokemon");
    var selectItem=document.getElementById("item");

    
    
    //option=new Array(numPlayerPokemon);
    

    //player.pokemonTeam[5].name="Psyduck";
    //initializes the switch list
    
    //Update the select display.
    if(firstLoad==false)
    {

        //This for loop is for taking away the previous values.
    
/* 
-------------IMPLEMENT ITEMS THE SAME AS SWITCHING POKEMON-------------
*/

        //Just resetting this string so I can reaccumulate with the updated values.
        selectItem.innerHTML="<option>Items</option>";
        for(i=0; i<player.items.length; i++)
        {
            //I need to accumulate this because this is all under one
            
            selectItem.innerHTML+="<option id="+ "\"" +i+"\""+"value= " + player.items[i].value +"> "+player.items[i].name + " value: "+ player.items[i].value+"<br>"+" </option>";
        }//End for

        
        
        selectPokemon.innerHTML="<option>Switch</option>";        
        //Loop that updates the new values in the switch box.
        for(i=0; i<numPlayerPokemon; i++)
        {
            //I need to accumulate this because this is all under one
            
            selectPokemon.innerHTML+="<option id="+ "\"" +i+"\""+"value= " + player.pokemonTeam[i].name +"> "+player.pokemonTeam[i].name + " HP: "+ player.pokemonTeam[i].hp+"<br>"+" </option>";
        }//End for

        //firstLoad=false;
    }//End if
    
    //Do this only once
    //This shouldn't happpen ever again for the rest of the match.
    if(firstLoad==true)
    {
        //Just resetting this string so I can reaccumulate with the updated values.
        //selectItem.innerHTML="<option>Items</option>";
        for(i=0; i<player.items.length; i++)
        {
            //I need to accumulate this because this is all under one
            
            selectItem.innerHTML+="<option id="+ "\"" +i+"\""+"value= " + player.items[i].value +"> "+player.items[i].name + " value: "+ player.items[i].value+"<br>"+" </option>";
        }//End for

        for(i=0; i<numPlayerPokemon; i++)
        {
            //I need to accumulate this because this is all under one
            selectPokemon.innerHTML+="<option id="+ "\"" +i+"\""+"value= " + player.pokemonTeam[i].name +"> "+player.pokemonTeam[i].name + " HP: "+ player.pokemonTeam[i].hp+"<br>"+" </option>";
            console.log(selectPokemon.innerHTML);    
        }//End for
        //The only time I declare this to be false.
        firstLoad=false;
    }//End if

    


}//End load

//Get all the data from the database into our trainer, opponent, and whatever else.
function init()
{



    //This is where I get put all of the database info into my things. I did some test initialization for debugging and stuff.
    /*

    */
    console.log(player.pokemonTeam[0].name+"!!!!!!!!!!!!!!!!!!!!!!!!!");
    load();


}//End init


//This ends the battle and updates the trainer values 
function end()
{
    // Reset to true incase I wanna implement a choice to rematch.
    // firstLoad=true;


    //disableAllMoves();
    //Disabling all battle realted buttons.
    opponentSwitchButton=document.getElementById("switchopponentpokemon");
    opponentItemButton=document.getElementById("opItem");
    playerswitchButton=document.getElementById("switchplayerpokemon");
    playerItemButton=document.getElementById("item");
    opponentSwitchButton.disabled=true;

    opponentItemButton.disabled=true;
    
    playerswitchButton.disabled=true;

    playerItemButton.disabled=true;
    for(i=0;i<totalPlayerMoves; i++)
    {   
        disableMove(i,true);
    }//End for

    for(i=0;i<totalOpponentMoves; i++)
    {   
        disableMove(i,false);
    }//End for

    var winMsg="You won!";        
    var loseMsg="End battle. You lose."
    if(opponent.isDefeated==true)
    {
         /*

    if(player.didCatchPokemon==true)
    {
        player.totalPokemon
        database.totalPokemon=player.totalPokemon
        //Insert code that adds the pokemon to database.
        
        database.add(player.caughtPokemon);
        //Or something like that.
    }//End if

    This will have all the end of battle updates such as level ups, money gains,
    pokemon catches, etc..

    Idea:

    database.level=Pokemonobject.level;
    display all the messages

    //Have a loop to see if the pokemon leveled up.
    for(i<numPlayerPokemon;i++)
    {
        if(player.pokemonTeam[i].)
    }//End for

    moneyMsg=player.name +"gained"+"$ opponent.money!!";
    levelUpMsg;
    display(moneyMsg);
    */
        display(winMsg);
    }//End if
    else if(player.isDefeated==true)
    {
    
        display(loseMsg);
        //End else
    }//End else if
   
}//End end